var require = meteorInstall({"server":{"methods.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/methods.js                                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Meteor.methods({                                                     // 1
    addResolution: function (resolution) {                           // 2
        check(resolution, String);                                   // 3
                                                                     //
        if (!Meteor.userId()) {                                      // 4
            throw new Meteor.Error('not-authorized');                // 5
        }                                                            // 6
                                                                     //
        Resolutions.insert({                                         // 7
            text: resolution,                                        // 8
            complete: false,                                         // 9
            createdAt: new Date(),                                   // 10
            user: Meteor.userId()                                    // 11
        });                                                          // 7
    },                                                               // 13
    updateResolution: function (id, resolution) {                    // 14
        check(resolution, String);                                   // 15
                                                                     //
        if (!Meteor.userId()) {                                      // 16
            throw new Meteor.Error('not-authorized');                // 17
        }                                                            // 18
                                                                     //
        Resolutions.update(id, {                                     // 19
            $set: {                                                  // 20
                text: resolution                                     // 21
            }                                                        // 20
        });                                                          // 19
    },                                                               // 24
    toggleResolution: function (resolution) {                        // 25
        check(resolution, Object);                                   // 26
                                                                     //
        if (Meteor.userId() !== resolution.user) {                   // 27
            throw new Meteor.Error('not-authorized');                // 28
        }                                                            // 29
                                                                     //
        Resolutions.update(resolution._id, {                         // 30
            $set: {                                                  // 31
                complete: !resolution.complete                       // 32
            }                                                        // 31
        });                                                          // 30
    },                                                               // 35
    deleteResolution: function (resolution) {                        // 36
        check(resolution, Object);                                   // 37
                                                                     //
        if (Meteor.userId() !== resolution.user) {                   // 38
            throw new Meteor.Error('not-authorized');                // 39
        }                                                            // 40
                                                                     //
        Resolutions.remove(resolution._id);                          // 41
    }                                                                // 42
});                                                                  // 1
///////////////////////////////////////////////////////////////////////

},"publish.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/publish.js                                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Resolutions = new Mongo.Collection("resolutions");                   // 1
Meteor.publish("allResolutions", function () {                       // 3
    return Resolutions.find({                                        // 4
        complete: false                                              // 4
    });                                                              // 4
});                                                                  // 5
Meteor.publish("userResolutions", function () {                      // 7
    return Resolutions.find({                                        // 8
        user: this.userId                                            // 8
    });                                                              // 8
});                                                                  // 9
///////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var Meteor = void 0;                                                 // 1
module.importSync("meteor/meteor", {                                 // 1
  Meteor: function (v) {                                             // 1
    Meteor = v;                                                      // 1
  }                                                                  // 1
}, 0);                                                               // 1
Meteor.startup(function () {// code to run on server at startup      // 3
});                                                                  // 5
///////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/methods.js");
require("./server/publish.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
